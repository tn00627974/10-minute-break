# BluePufferFish 角色資產

- BluePufferFish.glb：可載入 Three.js / Blender / glTF 應用程式的 3D 模型。
- BluePufferFish_Viewer.html：Three.js 360° 檢視器，含上下漂浮、身體微擺、尾鰭與側鰭程序動畫。
- BluePufferFish_TextureAtlas.png：AI 產生的外觀參考貼圖圖集；目前 GLB 使用獨立 PBR 材質，尚未將此圖集做 UV 對位。

## 開啟檢視器
請將 HTML 與 GLB 放在同一資料夾，於該資料夾執行：

```bash
python -m http.server 8000
```

再用瀏覽器開啟 http://localhost:8000/BluePufferFish_Viewer.html

注意：目前游泳動畫由 Three.js 檢視器即時驅動，並非內嵌於 GLB 的 glTF animation clip。模型為程序化建立的可愛風格初版，後續可再精修比例、鰭形與 UV 貼圖。
